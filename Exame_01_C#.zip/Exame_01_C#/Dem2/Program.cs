﻿namespace Dem2
{
    internal class Program
    {
        // 2. Consoante os valores dados, escolha o tipo de variável mais correto a definir

        string numero2 =  "20000000000000000000000000000021";

        string Joana;  

        char   simbolo = '$';
        
        string Carlos;

        string numero1 = "20000000000000000000000000000021"; 

        int numero = -1;  






        
    }
}
